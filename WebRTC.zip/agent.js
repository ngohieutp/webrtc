const configuration = { 'iceServers': [{ 'urls': 'stun:stun.l.google.com:19302' }] }
const peerConnection = new RTCPeerConnection(configuration);
peerConnection.addEventListener('connectionstatechange', event => {
    if (peerConnection.connectionState === 'connected') {
        console.log('Connected')
    }
});

peerConnection.addEventListener('icecandidate', event => {
    console.log(event);
});

async function answerCall() {
    const customerSDP = document.getElementById("customer-sdp").value;

    console.log(customerSDP);

    peerConnection.setRemoteDescription(new RTCSessionDescription({
        sdp: customerSDP,
        type: 'offer'
    }));

    const answer = await peerConnection.createAnswer();
    console.log(answer);

    document.getElementById("agent-sdp").value = answer.sdp;

    await peerConnection.setLocalDescription(answer);
}

