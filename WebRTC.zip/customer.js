const configuration = { 'iceServers': [{ 'urls': 'stun:stun.l.google.com:19302' }] }
const peerConnection = new RTCPeerConnection(configuration);

peerConnection.addEventListener('connectionstatechange', event => {
    if (peerConnection.connectionState === 'connected') {
        console.log('Connected')
    }
});

peerConnection.addEventListener('icecandidate', event => {
    console.log(event);
});

async function makeCall() {
    const offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(offer);

    document.getElementById("customer-sdp").value = offer.sdp;
    document.getElementById("connect-agent").style.display = 'block';
}

async function connectAgent() {
    const agentSDP = document.getElementById("agent-sdp").value;

    console.log(agentSDP);

    peerConnection.setRemoteDescription(new RTCSessionDescription({
        sdp: agentSDP,
        type: 'answer'
    }));

    console.log(peerConnection)
}

